import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page1',
  templateUrl: './page1.component.html',
  styleUrls: ['./page1.component.css']
})
export class Page1Component 
    implements OnInit {

  employeeName : string;
  msg: any;
  submitAction(empName)
  {
    this.employeeName = empName.value;
    console.log(" ---->> Page 1 : - "+this.employeeName);
  }

  showAcknowlegeMsg(event)
  {
    this.msg = event;
  }
  constructor() { }

  ngOnInit() {
  }

}
