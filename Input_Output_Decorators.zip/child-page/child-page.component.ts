import { Component, OnInit, Input, Output,EventEmitter } from '@angular/core';


@Component({
  selector: 'app-child-page',
  templateUrl: './child-page.component.html',
  styleUrls: ['./child-page.component.css']
})
export class ChildPageComponent implements OnInit {

  constructor() { }

  @Input() link_employeeName:string;
  
  @Output() acknowlegementMsg = new EventEmitter<string>();
  
  sendAcknowledgement()
  {
    this.acknowlegementMsg.emit("Child component :- Employee Registered!!! ");
  }

  ngOnInit() {
  }

}
